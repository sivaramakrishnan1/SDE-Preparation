import java.util.Arrays;
import java.util.Scanner;
public class Admin {
    static String userName = "suhail";
    static String password = "khan";
    static Scanner scan = new Scanner(System.in);

    public static void Dashboard(){
        System.out.println("Enter choiec\n1 Add Theater\n2 Remove Theater\n3 Main menu");
        int choice = scan.nextInt();
        switch (choice){
            case 1:
                addTheater();
                break;
            case 2:
                removeTheater();
                break;
            case 3:
                Bookings.dashBoard();
                break;
            default:
                System.out.println("Enter proper number");
        }
    }
    public static void addTheater() {
        System.out.println("Enter Theater name:");
        String theaterName = scan.next();
            System.out.println("Enter number of rows in theater");
            int rowTheater = scan.nextInt();
            System.out.println("Enter numver of Column in theater");
            int colTheatre = scan.nextInt();
            for(int i=0;i<TheaterSeating.theater.size();i++){
                if(TheaterSeating.theater.get(i).name.equals(theaterName)){
                    System.out.println("theater name is alredy exist");
                    Dashboard();
                    break;
                }
            }
            TheaterSeating obj = new TheaterSeating(theaterName, rowTheater, colTheatre);
            TheaterSeating.theater.add(obj);
            System.out.println("Theater created succesfuly");
    }

    public static void removeTheater(){
        for (int i=0;i<TheaterSeating.theater.size();i++) {
            System.out.println(i + TheaterSeating.theater.get(i).name);
        }
        System.out.println("Enter number to remove");
        int theaterId = scan.nextInt();
        if (theaterId>TheaterSeating.theater.size()){
            System.out.println("The entered number is not correct");
            removeTheater();
        }else {
            TheaterSeating.theater.remove(theaterId);
            System.out.println("Theater removed successfully");
        }

    }
}
