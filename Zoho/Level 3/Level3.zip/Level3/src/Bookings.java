import java.util.Arrays;
import java.util.Scanner;

public class Bookings {
    static Scanner scan = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("Welcome to Theater");
        dashBoard();

    }
    public static void dashBoard(){
        while (true) {
            System.out.println("Enter choice\n1 Admin\n2 User\n3 Exit");
            int choice = scan.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter Username");
                    String username = scan.next();
                    System.out.println("Enter password");
                    String password = scan.next();
                    if (username.equals(Admin.userName) && password.equals(Admin.password)) {
                        Admin.Dashboard();
                    } else {
                        System.out.println("Your username or password is wrong\n");
                    }
                    break;
                case 2:
                    User();
                    break;
                case 3:
                    return;
            }
        }
    }

    public static void User(){
        if(TheaterSeating.theater.size()>0) {
            System.out.println("Enter number to select theater");

            for (int i = 0; i < TheaterSeating.theater.size(); i++) {
                System.out.println(i + " " + TheaterSeating.theater.get(i).name);
            }
            int theaterid = scan.nextInt();
            System.out.println("Enter choice\n1 Book Ticket\n2 CancelTicket\n3 dashboard");
            int choice = scan.nextInt();
            switch (choice) {
                case 1:
                    bookTickets(theaterid);
                    break;
                case 2:
                    cancelTicket(theaterid);
                    break;
                case 3:
                    dashBoard();
            }
        }else{
            System.out.println("no theaters available");
            dashBoard();
        }
    }

    public static void bookTickets(int theaterId){
        System.out.println("wlecome to " + TheaterSeating.theater.get(theaterId).name + " Theater");
        System.out.println("Available tickets are");
        System.out.print("col     ");
        for(int i=0;i<TheaterSeating.theater.get(theaterId).colSize;i++){
            System.out.print( i + " ");
        }
        System.out.println();
        for(int i=0;i<TheaterSeating.theater.get(theaterId).rowSize;i++){
            System.out.print("Row " + i + " - ");
            for(int j=0;j<TheaterSeating.theater.get(theaterId).colSize;j++){
                System.out.print(TheaterSeating.theater.get(theaterId).seats[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("Enter row number");
        int rowSeat = scan.nextInt();
        System.out.println("Enter column number");
        int colSeat = scan.nextInt();
        if(rowSeat>=TheaterSeating.theater.get(theaterId).rowSize || colSeat>=TheaterSeating.theater.get(theaterId).colSize){
            System.out.println("Enter seat numbers correctly");
        }else if(TheaterSeating.theater.get(theaterId).seats[rowSeat][colSeat]!=0){
            System.out.println("The ticket is already booked");
        }else{
            TheaterSeating.theater.get(theaterId).seats[rowSeat][colSeat]=1;
            System.out.println("Your seats are booked");
        }

        for(int i=0;i<TheaterSeating.theater.get(theaterId).rowSize;i++){
            System.out.print("Row " + i + " - ");
            for(int j=0;j<TheaterSeating.theater.get(theaterId).colSize;j++){
                System.out.print(TheaterSeating.theater.get(theaterId).seats[i][j] + " ");
            }
            System.out.println();
        }
    }
    public static void cancelTicket(int theaterId){
        System.out.println("Enter Row number to cancel");
        int rowCancel = scan.nextInt();
        System.out.println("Enter column number to cancel");
        int colCancel = scan.nextInt();
        if(rowCancel>TheaterSeating.theater.get(theaterId).rowSize || colCancel>TheaterSeating.theater.get(theaterId).colSize) {
            System.out.println("Enter seat numbers correctly");
        }
        else if(TheaterSeating.theater.get(theaterId).seats[rowCancel][colCancel]==0){
            System.out.println("The seat is not yet booked");
        }else {
            TheaterSeating.theater.get(theaterId).seats[rowCancel][colCancel]=0;
            System.out.println("your ticket is canceled");
        }
    }
}
