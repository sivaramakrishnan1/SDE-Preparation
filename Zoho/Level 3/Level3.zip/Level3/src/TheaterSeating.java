import java.util.ArrayList;

public class TheaterSeating {
    int rowSize,colSize;
    int seats[][];
    String name;
    static ArrayList<TheaterSeating> theater= new ArrayList<TheaterSeating>();
    TheaterSeating(String theaterName, int rowSize,int colSize){
        this.name = theaterName;
        this.rowSize = rowSize;
        this.colSize = colSize;
        this.seats = new int[this.rowSize][this.colSize];
    }








}
